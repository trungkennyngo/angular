import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Subject } from "rxjs";
import { Observable } from "rxjs";

@Injectable({
  providedIn: "root"
})
export class HttpService {
  private subject = new Subject<any>();

  constructor(private http: HttpClient) {}

  sendMessage(message: string) {
    this.http
      .get("https://jsonplaceholder.typicode.com/todos/1")
      .subscribe(response => {
        this.subject.next({ text: response });
      });
  }

  clearMessage() {
    this.subject.next();
  }

  getMessage(): Observable<any> {
    return this.subject.asObservable();
  }
}
