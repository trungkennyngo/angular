import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

// ngrx
import { StoreModule } from "@ngrx/store";
import { StoreDevtoolsModule } from "@ngrx/store-devtools";
import { appReducers } from "./app.reducers";
import { Routes, RouterModule } from "@angular/router";

// Forms
import { ReactiveFormsModule } from "@angular/forms";

import { AppComponent } from "./app.component";
import { TodoComponent } from "./todo/todo.component";
import { TodosListComponent } from "./todo/todos-list/todos-list.component";
import { TodoItemComponent } from "./todo/todo-item/todo-item.component";
import { TodoAddComponent } from "./todo/todo-add/todo-add.component";
import { environment } from "../environments/environment";
import { FilterPipe } from "./filter/filter.pipe";
import { HttpClientModule } from '@angular/common/http';

const routes: Routes = [
  {
    path: "",
    component: TodoComponent,
    pathMatch: "full"
  },
  {
    path: "shop",
    loadChildren: "./shop/shop.module#ShopModule"
  }
];

@NgModule({
  declarations: [
    AppComponent,
    TodoComponent,
    TodosListComponent,
    TodoItemComponent,
    TodoAddComponent,
    FilterPipe
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    StoreModule.forRoot(appReducers),
    StoreDevtoolsModule.instrument({
      maxAge: 25, // Retains last 25 states
      logOnly: environment.production // Restrict extension to log-only mode
    }),
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
