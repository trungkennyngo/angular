import { Component, OnInit } from "@angular/core";
import { ToggleAllTodoAction } from "./todo.actions";
import { Store } from "@ngrx/store";
import { AppState } from "../app.reducers";
import { Router } from "@angular/router";
import { HttpService } from "../http.service";
import { Subscription } from "rxjs";

@Component({
  selector: "app-todo",
  templateUrl: "./todo.component.html",
  styles: []
})
export class TodoComponent implements OnInit {
  completado = false;

  message: any;
  subscription: Subscription;

  // subscribe to home component messages

  constructor(
    private store: Store<AppState>,
    public router: Router,
    public service: HttpService
  ) {
    this.subscription = this.service.getMessage().subscribe(message => {
      console.log("HTTP GET API TEST RESULT--", message);
      this.message = message;
    });
  }

  sendMessage(): void {
    // send message to subscribers via observable subject
    this.service.sendMessage("Message from Home Component to App Component!");
  }

  ngOnInit() {
    this.sendMessage();
  }

  checkRoute() {
    this.router.navigate(["/test"]);
  }

  toggleAll() {
    this.completado = !this.completado;

    const accion = new ToggleAllTodoAction(this.completado);
    this.store.dispatch(accion);
  }
}
