module.exports = require('./webpack.config-helper')({
    isProduction: true,
});