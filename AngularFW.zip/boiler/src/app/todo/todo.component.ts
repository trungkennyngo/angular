import { Component, OnInit } from '@angular/core';
import { ToggleAllTodoAction } from './todo.actions';
import { Store } from '@ngrx/store';
import { AppState } from '../app.reducers';
import { Router } from '@angular/router';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styles: []
})
export class TodoComponent implements OnInit {

  completado = false;

  constructor(private store: Store<AppState>,public router: Router) { }

ngOnInit(){}

  checkRoute(){
    this.router.navigate(['/test']);
  }

  toggleAll() {
    this.completado = !this.completado;

    const accion = new ToggleAllTodoAction(this.completado);
    this.store.dispatch(accion);
  }

}
